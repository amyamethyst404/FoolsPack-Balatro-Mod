
SMODS.Consumable {
    key = 'uncstillgotit',
    set = 'heros_and_vilnians',
    pos = { x = 5, y = 1 },
    loc_txt = {
        name = 'Unc still got it',
        text = {
            [1] = 'Draw {C:green}10  {}random cards to your Hand'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    soul_pos = {
        x = 6,
        y = 1
    },
    use = function(self, card, area, copier)
        local used_card = copier or card
        if G.hand and #G.hand.cards > 0 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(10).." Cards Drawn", colour = G.C.BLUE})
                    SMODS.draw_cards(10)
                    return true
                end
            }))
            delay(0.6)
        end
    end,
    can_use = function(self, card)
        return true
    end
}