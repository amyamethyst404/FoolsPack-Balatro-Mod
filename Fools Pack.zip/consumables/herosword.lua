
SMODS.Consumable {
    key = 'herosword',
    set = 'heros_and_vilnians',
    pos = { x = 4, y = 0 },
    config = { 
        extra = {
            blind_size0 = 0.75   
        } 
    },
    loc_txt = {
        name = 'Hero_Sword',
        text = {
            [1] = 'Lowers Blind Requierment by {C:green}25%{}'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    soul_pos = {
        x = 5,
        y = 0
    },
    use = function(self, card, area, copier)
        local used_card = copier or card
        return {
            
            func = function()
                if G.GAME.blind.in_blind then
                    
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "slash", colour = G.C.GREEN})
                    G.GAME.blind.chips = G.GAME.blind.chips * 0.75
                    G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                    G.HUD_blind:recalculate()
                    return true
                end
            end
        }
    end,
    can_use = function(self, card)
        return true
    end
}