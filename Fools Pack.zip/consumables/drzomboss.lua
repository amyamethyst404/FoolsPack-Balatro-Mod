
SMODS.Consumable {
    key = 'drzomboss',
    set = 'heros_and_vilnians',
    pos = { x = 2, y = 4 },
    loc_txt = {
        name = 'Dr Zomboss',
        text = {
            [1] = 'Flips all Jokers'
        }
    },
    cost = 5,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    soul_pos = {
        x = 3,
        y = 4
    },
    use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.jokers.cards > 0 then
            for _, joker in ipairs(G.jokers.cards) do
                joker:flip()
            end
        end
        return {
            message = "Flip!"
        }
    end,
    can_use = function(self, card)
        return true
    end
}