
SMODS.Consumable {
    key = 'balatroslove',
    set = 'heros_and_vilnians',
    pos = { x = 6, y = 4 },
    loc_txt = {
        name = 'Balatros Love',
        text = {
            [1] = '{C:green}Sets Ante to 1{}',
            [2] = 'Grants {C:red}EVERY {}{C:attention}voucher{}',
            [3] = 'Grants{C:diamonds} $1000 {}',
            [4] = 'Every Joker will spawn {C:purple}negative{}'
        }
    },
    cost = 0,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        error("You actually thought this would work?")
    end,
    can_use = function(self, card)
        return true
    end
}