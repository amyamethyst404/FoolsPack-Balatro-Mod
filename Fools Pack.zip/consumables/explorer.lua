
SMODS.Consumable {
    key = 'explorer',
    set = 'heros_and_vilnians',
    pos = { x = 3, y = 3 },
    loc_txt = {
        name = 'Explorer',
        text = {
            [1] = 'Draw 3 random cards to hand'
        }
    },
    cost = 3,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    soul_pos = {
        x = 4,
        y = 3
    },
    use = function(self, card, area, copier)
        local used_card = copier or card
        if G.hand and #G.hand.cards > 0 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(3).." Cards Drawn", colour = G.C.BLUE})
                    SMODS.draw_cards(3)
                    return true
                end
            }))
            delay(0.6)
        end
    end,
    can_use = function(self, card)
        return true
    end
}