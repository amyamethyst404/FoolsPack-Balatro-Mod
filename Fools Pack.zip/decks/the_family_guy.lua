
SMODS.Back {
    key = 'the_family_guy',
    pos = { x = 1, y = 0 },
    config = {
        no_interest = true,
    },
    loc_txt = {
        name = 'The Family Guy',
        text = {
            [1] = 'It seems {C:red}Today...{}',
            [2] = '',
            [3] = 'Makes You {C:green}Laugh{} And {C:blue}Cry{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('timpani')
                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                    local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_fagmod_peter' })
                    if new_joker then
                        new_joker:add_sticker('eternal', true)
                    end
                    G.GAME.joker_buffer = 0
                end
                return true
            end
        }))
        G.GAME.modifiers.money_per_hand = 0
        G.GAME.modifiers.money_per_discard = 0
        G.GAME.starting_params.dollars = 100
        G.GAME.modifiers.money_per_hand = 0
    end
}