
SMODS.Back {
    key = 'nonedeck',
    pos = { x = 9, y = 0 },
    config = {
        extra = {
            shop_slots0 = 0,
            voucher_slots0 = 0
        },
        no_interest = true,
    },
    loc_txt = {
        name = '???',
        text = {
            [1] = '???'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound('timpani')
                    local new_joker = SMODS.add_card({ set = 'Joker' })
                    if new_joker then
                        new_joker:add_sticker('eternal', true)
                    end
                    return true
                end
            }))
        end
    end,
    apply = function(self, back)
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    local current_shop_slots = (G.GAME.modifiers.shop_size or 0)
                    local target_shop_slots = 0
                    local difference = target_shop_slots - current_shop_slots
                    change_shop_size(difference)
                    return true
                end
            })),
            extra = {
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        
                        local current_voucher_slots = (G.GAME.modifiers.extra_vouchers or 0)
                        local target_voucher_slots = 0
                        local difference = target_voucher_slots - current_voucher_slots
                        SMODS.change_voucher_limit(difference)
                        return true
                    end
                })),
                colour = G.C.WHITE,
                extra = {
                    
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            G.GAME.round_resets.reroll_cost = G.GAME.round_resets.reroll_cost + 999
                            G.GAME.current_round.reroll_cost = math.max(0,
                            G.GAME.current_round.reroll_cost + 999)
                            return true
                        end
                    }))
                    ,
                    colour = G.C.BLUE
                }
            }
        }
    end
}