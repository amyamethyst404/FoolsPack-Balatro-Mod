
SMODS.Back {
    key = 'frienddeck',
    pos = { x = 2, y = 0 },
    config = {
        extra = {
            booster_slots0 = 0,
            voucher_slots0 = 0
        },
    },
    loc_txt = {
        name = 'Friend_Deck',
        text = {
            [1] = '{C:money}Friend Friend Friend{} {C:purple}Friend Friend Friend{}',
            [2] = '{C:money}Friend Friend Friend{} {C:purple}Friend Friend Friend{}',
            [3] = '{C:money}Friend Friend Friend{} {C:purple}Friend Friend Friend{}',
            [4] = '{C:money}Friend Friend Friend{} {C:purple}Friend Friend Friend{}',
            [5] = '{C:money}Friend Friend Friend{} {C:purple}Friend Friend Friend{}',
            [6] = '{C:money}Friend Friend Friend{} {C:purple}Friend Friend Friend{}',
            [7] = '{C:money}Friend Friend Friend{} {C:purple}Friend Friend Friend{}',
            [8] = ''
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.starting_shop then
            return {
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        
                        local current_booster_slots = (G.GAME.modifiers.extra_boosters or 0)
                        local target_booster_slots = 0
                        local difference = target_booster_slots - current_booster_slots
                        SMODS.change_booster_limit(difference)
                        return true
                    end
                })),
                extra = {
                    
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            
                            
                            local current_voucher_slots = (G.GAME.modifiers.extra_vouchers or 0)
                            local target_voucher_slots = 0
                            local difference = target_voucher_slots - current_voucher_slots
                            SMODS.change_voucher_limit(difference)
                            return true
                        end
                    })),
                    colour = G.C.WHITE
                }
            }
        end
    end,
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                for k, v in pairs(G.playing_cards) do
                    v:set_ability(G.P_CENTERS['m_fagmod_friend'])
                end
                G.GAME.starting_deck_size = #G.playing_cards
                return true
            end
        }))
        G.GAME.win_ante = 9
        G.GAME.starting_params.hands = 1
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('timpani')
                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                    local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_fagmod_sodapop' })
                    if new_joker then
                    end
                    G.GAME.joker_buffer = 0
                end
                return true
            end
        }))
    end
}