
SMODS.Back {
    key = 'fools_deck',
    pos = { x = 8, y = 0 },
    config = {
        extra = {
            repetitions = 2
        },
    },
    loc_txt = {
        name = 'Fools Deck',
        text = {
            [1] = 'Start with {C:green}2 Random{}',
            [2] = '{X:tarot,C:white}FoolsPack {} Jokers',
            [3] = '',
            [4] = '{C:inactive}Image is currently a place',
            [5] = 'holder while ziggy finishes it lol{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        for i = 1, 2 do
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound('timpani')
                    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                        local new_joker = SMODS.add_card({ set = 'fagmod_fagmod_jokers' })
                        if new_joker then
                        end
                        G.GAME.joker_buffer = 0
                    end
                    return true
                end
            }))
            
        end
    end
}