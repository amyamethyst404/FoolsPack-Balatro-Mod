
SMODS.Back {
    key = 'court_of_the_jester',
    pos = { x = 7, y = 0 },
    config = {
        extra = {
            remove_starting_cards_count0 = 52,
            add_starting_cards_count0 = 12
        },
    },
    loc_txt = {
        name = 'Court of the Jester',
        text = {
            [1] = '{C:dark_edition}Erratic deck effect{}',
            [2] = '{C:attention}Only {}has{C:spades} Face cards{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                for i=#G.deck.cards, 1, -1 do
                    G.deck.cards[i]:remove()
                end
                return true
            end
        }))
        G.E_MANAGER:add_event(Event({
            delay = 0.3,
            func = function()
                local cards = {}
                for i = 1, 12 do
                    local faces = {}
                    for _, rank_key in ipairs(SMODS.Rank.obj_buffer) do
                        local rank = SMODS.Ranks[rank_key]
                    if rank.face then table.insert(faces, rank) end
                    end
                    local _rank = pseudorandom_element(faces, 'add_face_cards').card_key
                    local _suit = nil
                    local new_card_params = { set = "Base", area = G.deck }
                if _rank then new_card_params.rank = _rank end
                if _suit then new_card_params.suit = _suit end
                    cards[i] = SMODS.add_card(new_card_params)
                end
                SMODS.calculate_context({ playing_card_added = true, cards = cards })
                G.GAME.starting_deck_size = #G.playing_cards
                return true
            end
        }))
    end
}