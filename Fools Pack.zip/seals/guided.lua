
SMODS.Seal {
    key = 'guided',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            xchips0 = 1.5
        }
    },
    badge_colour = HEX('8abdff'),
    loc_txt = {
        name = 'Guided',
        label = 'Guided',
        text = {
            [1] = '{X:blue,C:white}X1.5 Chips{} When held in hand'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    sound = { sound = "foil1", per = 1.2, vol = 0.4 },
    calculate = function(self, card, context)
        if context.cardarea == G.hand and context.main_scoring then
            return {
                x_chips = 1.5
            }
        end
    end
}