SMODS.Rarity {
    key = "deck_exclusive",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('000000'),
    loc_txt = {
        name = "Deck Exclusive"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "joe",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.421,
    badge_colour = HEX('7ed321'),
    loc_txt = {
        name = "Joe"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}