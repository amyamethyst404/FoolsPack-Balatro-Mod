
SMODS.Enhancement {
    key = 'friend',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            FriendChips = 0,
            FriendMult = 0
        }
    },
    loc_txt = {
        name = 'Friend',
        text = {
            [1] = 'Gives {C:blue}???{}',
            [2] = 'Gives {C:red}???{}',
            [3] = '{C:attention}Frie{}{C:purple}nd....{}'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = true,
    no_rank = true,
    no_suit = true,
    always_scores = true,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 0,
    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.FriendChips, card.ability.extra.FriendMult}}
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            card.ability.extra.FriendChips = pseudorandom('RANGE:0|50', 0, 50)
            card.ability.extra.FriendMult = pseudorandom('RANGE:-5|25', -5, 25)
            return {
                chips = card.ability.extra.FriendChips,
                extra = {
                    mult = card.ability.extra.FriendMult
                }
            }
        end
    end
}