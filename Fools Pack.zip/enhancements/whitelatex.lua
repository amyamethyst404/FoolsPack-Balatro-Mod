
SMODS.Enhancement {
    key = 'whitelatex',
    pos = { x = 3, y = 0 },
    config = {
        extra = {
            blindchiprequirement = 0,
            Chips = 0
        }
    },
    loc_txt = {
        name = 'white latex',
        text = {
            [1] = 'Removes {C:attention}Rank{}',
            [2] = 'Adds {C:blue}Chips {}equal to {C:green}1%{} of blind total'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = true,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 0,
    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Chips, ((G.GAME.blind.chips or 0)) * 0.01}}
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            card.ability.extra.Chips = (G.GAME.blind.chips) * 0.01
            return {
                chips = card.ability.extra.Chips
            }
        end
    end
}