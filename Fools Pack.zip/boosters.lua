
SMODS.Booster {
    key = 'light_and_dark',
    loc_txt = {
        name = "Light and Dark",
        text = {
            [1] = 'Pick {C:green}1 out of 3{} {C:red}Hero and Villians {}Cards'
        },
        group_name = "fagmod_boosters"
    },
    config = { extra = 3, choose = 1 },
    cost = 5,
    weight = 3.9,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    group_key = "fagmod_boosters",
    select_card = "consumeables",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
            set = "heros_and_vilnians",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "fagmod_light_and_dark"
        }
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}


SMODS.Booster {
    key = 'happiness_and_pain',
    loc_txt = {
        name = "Happiness and Pain",
        text = {
            [1] = 'Pick {C:green}1 out of 5{} {C:red}Hero and Villians {}Cards'
        },
        group_name = "fagmod_boosters"
    },
    config = { extra = 5, choose = 1 },
    cost = 7,
    weight = 1.1,
    atlas = "CustomBoosters",
    pos = { x = 1, y = 0 },
    group_key = "fagmod_boosters",
    select_card = "consumeables",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
            set = "heros_and_vilnians",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "fagmod_happiness_and_pain"
        }
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}


SMODS.Booster {
    key = 'real_and_fake',
    loc_txt = {
        name = "Real and Fake",
        text = {
            [1] = 'Pick {C:green}1 out of 5{} {C:red}Hero and Villians {}Cards'
        },
        group_name = "fagmod_boosters"
    },
    config = { extra = 5, choose = 1 },
    cost = 7,
    weight = 1.1,
    atlas = "CustomBoosters",
    pos = { x = 2, y = 0 },
    group_key = "fagmod_boosters",
    select_card = "consumeables",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
            set = "heros_and_vilnians",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "fagmod_real_and_fake"
        }
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}


SMODS.Booster {
    key = 'life_and_death',
    loc_txt = {
        name = "Life and Death",
        text = {
            [1] = 'Pick {C:green}1 out of 3{} {C:red}Hero and Villians {}Cards'
        },
        group_name = "fagmod_boosters"
    },
    config = { extra = 3, choose = 1 },
    cost = 5,
    weight = 4.7,
    atlas = "CustomBoosters",
    pos = { x = 3, y = 0 },
    group_key = "fagmod_boosters",
    select_card = "consumeables",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
            set = "heros_and_vilnians",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "fagmod_life_and_death"
        }
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}
