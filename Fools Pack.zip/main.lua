SMODS.Atlas({
    key = "modicon", 
    path = "ModIcon.png", 
    px = 34,
    py = 34,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "balatro", 
    path = "balatro.png", 
    px = 333,
    py = 216,
    prefix_config = { key = false },
    atlas_table = "ASSET_ATLAS"
})


SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomConsumables", 
    path = "CustomConsumables.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomBoosters", 
    path = "CustomBoosters.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomEnhancements", 
    path = "CustomEnhancements.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomSeals", 
    path = "CustomSeals.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
}):register()

SMODS.Atlas({
    key = "CustomDecks", 
    path = "CustomDecks.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end

local jokerIndexList = {31,72,15,8,70,54,4,55,11,26,50,24,19,29,37,36,78,63,35,64,62,52,1,38,69,61,43,68,44,67,74,66,18,12,77,53,39,30,40,6,2,56,65,3,46,45,20,25,32,34,5,60,33,17,76,22,41,71,48,27,23,49,28,73,7,42,75,21,16,51,10,9,47,58,13,14,59,57}

local function load_jokers_folder()
    local mod_path = SMODS.current_mod.path
    local jokers_path = mod_path .. "/jokers"
    local files = NFS.getDirectoryItemsInfo(jokers_path)
    for i = 1, #jokerIndexList do
        local file_name = files[jokerIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("jokers/" .. file_name))()
        end
    end
end


local consumableIndexList = {19,3,11,13,12,14,22,21,25,26,20,4,7,24,23,17,1,16,9,15,6,10,5,18,8,27,2}

local function load_consumables_folder()
    local mod_path = SMODS.current_mod.path
    local consumables_path = mod_path .. "/consumables"
    local files = NFS.getDirectoryItemsInfo(consumables_path)
    local set_file_number = #files + 1
    for i = 1, #files do
        if files[i].name == "sets.lua" then
            assert(SMODS.load_file("consumables/sets.lua"))()
            set_file_number = i
        end
    end    
    for i = 1, #consumableIndexList do
        local j = consumableIndexList[i]
        if j >= set_file_number then 
            j = j + 1
        end
        local file_name = files[j].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("consumables/" .. file_name))()
        end
    end
end


local enhancementIndexList = {1,3,2,4}

local function load_enhancements_folder()
    local mod_path = SMODS.current_mod.path
    local enhancements_path = mod_path .. "/enhancements"
    local files = NFS.getDirectoryItemsInfo(enhancements_path)
    for i = 1, #enhancementIndexList do
        local file_name = files[enhancementIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("enhancements/" .. file_name))()
        end
    end
end


local sealIndexList = {1}

local function load_seals_folder()
    local mod_path = SMODS.current_mod.path
    local seals_path = mod_path .. "/seals"
    local files = NFS.getDirectoryItemsInfo(seals_path)
    for i = 1, #sealIndexList do
        local file_name = files[sealIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("seals/" .. file_name))()
        end
    end
end


local editionIndexList = {1}

local function load_editions_folder()
    local mod_path = SMODS.current_mod.path
    local editions_path = mod_path .. "/editions"
    local files = NFS.getDirectoryItemsInfo(editions_path)
    for i = 1, #editionIndexList do
        local file_name = files[editionIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("editions/" .. file_name))()
        end
    end
end


local deckIndexList = {6,10,3,4,5,8,9,1,2,7}

local function load_decks_folder()
    local mod_path = SMODS.current_mod.path
    local decks_path = mod_path .. "/decks"
    local files = NFS.getDirectoryItemsInfo(decks_path)
    for i = 1, #deckIndexList do
        local file_name = files[deckIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("decks/" .. file_name))()
        end
    end
end

local function load_rarities_file()
    local mod_path = SMODS.current_mod.path
    assert(SMODS.load_file("rarities.lua"))()
end

load_rarities_file()

local function load_boosters_file()
    local mod_path = SMODS.current_mod.path
    assert(SMODS.load_file("boosters.lua"))()
end

load_boosters_file()
assert(SMODS.load_file("sounds.lua"))()
load_jokers_folder()
load_consumables_folder()
load_enhancements_folder()
load_seals_folder()
load_editions_folder()
load_decks_folder()
SMODS.ObjectType({
    key = "fagmod_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "fagmod_fagmod_jokers",
    cards = {
        ["j_fagmod__203867"] = true,
        ["j_fagmod_advantagepoint"] = true,
        ["j_fagmod_affectionaddiction"] = true,
        ["j_fagmod_baldi"] = true,
        ["j_fagmod_bigboobs"] = true,
        ["j_fagmod_birdbrain"] = true,
        ["j_fagmod_biteof87"] = true,
        ["j_fagmod_casual"] = true,
        ["j_fagmod_clownfish"] = true,
        ["j_fagmod_copycat"] = true,
        ["j_fagmod_crushedjoe"] = true,
        ["j_fagmod_doomscroller"] = true,
        ["j_fagmod_dragonet"] = true,
        ["j_fagmod_droplet"] = true,
        ["j_fagmod_dummy"] = true,
        ["j_fagmod_eughh"] = true,
        ["j_fagmod_expertssay"] = true,
        ["j_fagmod_flopera"] = true,
        ["j_fagmod_furiousjoe"] = true,
        ["j_fagmod_gimmickgirl"] = true,
        ["j_fagmod_godohfuckingwhy"] = true,
        ["j_fagmod_gokupenis"] = true,
        ["j_fagmod_greatvalueblueberries"] = true,
        ["j_fagmod_happyjoe"] = true,
        ["j_fagmod_harsunemieku"] = true,
        ["j_fagmod_healthyjoe"] = true,
        ["j_fagmod_hey"] = true,
        ["j_fagmod_heyguys"] = true,
        ["j_fagmod_heypetah"] = true,
        ["j_fagmod_human"] = true,
        ["j_fagmod_infocard"] = true,
        ["j_fagmod_inthisbeautifulworld"] = true,
        ["j_fagmod_isaac"] = true,
        ["j_fagmod_jestria"] = true,
        ["j_fagmod_joedice"] = true,
        ["j_fagmod_knight"] = true,
        ["j_fagmod_len"] = true,
        ["j_fagmod_lostmedia"] = true,
        ["j_fagmod_machinelove"] = true,
        ["j_fagmod_markfischbach"] = true,
        ["j_fagmod_meangirl"] = true,
        ["j_fagmod_oldman"] = true,
        ["j_fagmod_onthewaydown"] = true,
        ["j_fagmod_outofcontrol"] = true,
        ["j_fagmod_outsideyourhouse"] = true,
        ["j_fagmod_peak"] = true,
        ["j_fagmod_peter"] = true,
        ["j_fagmod_pineapplejoeseph"] = true,
        ["j_fagmod_pinkaplier"] = true,
        ["j_fagmod_potassium"] = true,
        ["j_fagmod_rin"] = true,
        ["j_fagmod_rosie"] = true,
        ["j_fagmod_scaryjoe"] = true,
        ["j_fagmod_scratch"] = true,
        ["j_fagmod_seabird"] = true,
        ["j_fagmod_seadrive"] = true,
        ["j_fagmod_selfish"] = true,
        ["j_fagmod_sharkitty"] = true,
        ["j_fagmod_silenthero"] = true,
        ["j_fagmod_sneeze"] = true,
        ["j_fagmod_sodapop"] = true,
        ["j_fagmod_sodashar"] = true,
        ["j_fagmod_spokenfor"] = true,
        ["j_fagmod_static"] = true,
        ["j_fagmod_superlaserpiss"] = true,
        ["j_fagmod_theboy"] = true,
        ["j_fagmod_toothpasteboy"] = true,
        ["j_fagmod_tumor"] = true,
        ["j_fagmod_updatenotes"] = true,
        ["j_fagmod_wasthatthe"] = true,
        ["j_fagmod_weare"] = true,
        ["j_fagmod_welcome"] = true,
        ["j_fagmod_wigglemcgigglejiggle"] = true,
        ["j_fagmod_xboxlive"] = true
    },
})

SMODS.ObjectType({
    key = "fagmod_Vocaloid",
    cards = {
        ["j_fagmod_advantagepoint"] = true,
        ["j_fagmod_affectionaddiction"] = true,
        ["j_fagmod_birdbrain"] = true,
        ["j_fagmod_doomscroller"] = true,
        ["j_fagmod_flopera"] = true,
        ["j_fagmod_gimmickgirl"] = true,
        ["j_fagmod_harsunemieku"] = true,
        ["j_fagmod_human"] = true,
        ["j_fagmod_len"] = true,
        ["j_fagmod_lostmedia"] = true,
        ["j_fagmod_machinelove"] = true,
        ["j_fagmod_onthewaydown"] = true,
        ["j_fagmod_outofcontrol"] = true,
        ["j_fagmod_rin"] = true,
        ["j_fagmod_scratch"] = true,
        ["j_fagmod_spokenfor"] = true,
        ["j_fagmod_static"] = true,
        ["j_fagmod_weare"] = true,
        ["j_fagmod_wordplay"] = true
    },
})

SMODS.ObjectType({
    key = "fagmod_mark",
    cards = {
        ["j_fagmod_biteof87"] = true,
        ["j_fagmod_eughh"] = true,
        ["j_fagmod_godohfuckingwhy"] = true,
        ["j_fagmod_markfischbach"] = true,
        ["j_fagmod_pinkaplier"] = true,
        ["j_fagmod_wasthatthe"] = true,
        ["j_fagmod_welcome"] = true
    },
})

SMODS.ObjectType({
    key = "fagmod_joe_jokers",
    cards = {
        ["j_fagmod_furiousjoe"] = true,
        ["j_fagmod_happyjoe"] = true,
        ["j_fagmod_heypetah"] = true,
        ["j_fagmod_pineapplejoeseph"] = true,
        ["j_fagmod_scaryjoe"] = true
    },
})

SMODS.ObjectType({
    key = "fagmod_fagmod_jokers joe_jokers",
    cards = {
        ["j_fagmod_joemama"] = true
    },
})

SMODS.ObjectType({
    key = "fagmod_fagmod_jokers joe_jockers",
    cards = {
        ["j_fagmod_johnapple"] = true
    },
})

SMODS.ObjectType({
    key = "fagmod_fagmod_joker",
    cards = {
        ["j_fagmod_wordplay"] = true
    },
})


SMODS.current_mod.optional_features = function()
    return {
        cardareas = {} 
    }
end