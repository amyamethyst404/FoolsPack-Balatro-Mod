
SMODS.Joker{ --John apple
    key = "johnapple",
    config = {
        extra = {
            shop_slots_increase = '1',
            nom = 0
        }
    },
    loc_txt = {
        ['name'] = 'John apple',
        ['text'] = {
            [1] = '{C:attention}Increases Card slots{} in the Shop by {C:green}1{}',
            [2] = 'Gets eaten after {C:uncommon}3 Rerolls{}',
            [3] = '',
            [4] = '{C:inactive}Currentlly #1#/3{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = "fagmod_joe",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers joe_jockers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.nom}}
    end,
    
    calculate = function(self, card, context)
        if context.reroll_shop  then
            if to_big((card.ability.extra.nom or 0)) >= to_big(3) then
                return {
                    func = function()
                        local target_joker = card
                        
                        if target_joker then
                            if target_joker.ability.eternal then
                                target_joker.ability.eternal = nil
                            end
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "nom nom nom", colour = G.C.RED})
                        end
                        return true
                    end
                }
            else
                return {
                    func = function()
                        card.ability.extra.nom = (card.ability.extra.nom) + 1
                        return true
                    end
                }
            end
        end
    end,
    
    add_to_deck = function(self, card, from_debuff)
        change_shop_size(1)
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        change_shop_size(-1)
    end
}