
SMODS.Joker{ --Experts say...
    key = "expertssay",
    config = {
        extra = {
            odds = 4,
            odds2 = 10,
            chips0 = 1,
            mult0 = 1,
            card_draw0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Experts say...',
        ['text'] = {
            [1] = 'Lets {C:red}think {}about this'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_fagmod_expertssay')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_fagmod_expertssay')
        local new_numerator3, new_denominator3 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds3, 'j_fagmod_expertssay')
        local new_numerator4, new_denominator4 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds4, 'j_fagmod_expertssay')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2, new_numerator3, new_denominator3, new_numerator4, new_denominator4}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_38975e1b', 1, card.ability.extra.odds, 'j_fagmod_expertssay', false) then
                    SMODS.calculate_effect({chips = 1}, card)
                end
                if SMODS.pseudorandom_probability(card, 'group_1_4b8432a8', 1, card.ability.extra.odds, 'j_fagmod_expertssay', false) then
                    SMODS.calculate_effect({mult = 1}, card)
                end
                if SMODS.pseudorandom_probability(card, 'group_2_06d20b83', 1, card.ability.extra.odds, 'j_fagmod_expertssay', false) then
                    if G.hand and #G.hand.cards > 0 then
                        SMODS.draw_cards(1)
                    end
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Cards Drawn", colour = G.C.BLUE})
                end
                if SMODS.pseudorandom_probability(card, 'group_3_ce35a64c', 1, card.ability.extra.odds2, 'j_fagmod_expertssay', true) then
                    error("EasternFarmer Was Here")
                    
                end
            end
        end
    end
}