
SMODS.Joker{ --Outside your house
    key = "outsideyourhouse",
    config = {
        extra = {
            xmult0 = 1.25
        }
    },
    loc_txt = {
        ['name'] = 'Outside your house',
        ['text'] = {
            [1] = 'Every {C:hearts}Heart{} or {C:spades}Spade{} card {C:attention}scored{}',
            [2] = 'gives {X:red,C:white}1.25x Mult{}',
            [3] = '{C:inactive}art by @AintSoro on twitter{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:is_suit("Hearts") or context.other_card:is_suit("Spades")) then
                return {
                    Xmult = 1.25
                }
            end
        end
    end
}