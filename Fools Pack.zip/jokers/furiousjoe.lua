
SMODS.Joker{ --Furious Joe
    key = "furiousjoe",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Furious Joe',
        ['text'] = {
            [1] = 'He costs {C:red}$5{} he mad as hell',
            [2] = '',
            [3] = '{C:rare}3:<{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "fagmod_joe",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true, ["fagmod_joe_jokers"] = true },
    
    calculate = function(self, card, context)
        if (context.end_of_round or context.reroll_shop or context.buying_card or
            context.selling_card or context.ending_shop or context.starting_shop or 
            context.ending_booster or context.skipping_booster or context.open_booster or
            context.skip_blind or context.before or context.pre_discard or context.setting_blind or
        context.using_consumeable)   then
            return {
                message = "3:<"
            }
        end
    end
}