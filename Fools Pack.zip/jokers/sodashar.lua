
SMODS.Joker{ --Sodashar
    key = "sodashar",
    config = {
        extra = {
            MultLevel = 7,
            mostrecenthandlevel = 1
        }
    },
    loc_txt = {
        ['name'] = 'Sodashar',
        ['text'] = {
            [1] = 'Adds {C:attention}Triple the previous played hand level{}',
            [2] = 'To {C:red}Mult + 2{} {C:inactive}(#1#){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.MultLevel, card.ability.extra.mostrecenthandlevel + (((G.GAME.last_hand_played and G.GAME.hands[G.GAME.last_hand_played] and G.GAME.hands[G.GAME.last_hand_played].level or 0) or 0))}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            local MultLevel_value = card.ability.extra.MultLevel
            card.ability.extra.MultLevel = card.ability.extra.mostrecenthandlevel + ((G.GAME.last_hand_played and G.GAME.hands[G.GAME.last_hand_played] and G.GAME.hands[G.GAME.last_hand_played].level or 0))
            card.ability.extra.MultLevel = (card.ability.extra.MultLevel) * 3
            return {
                mult = MultLevel_value
            }
        end
    end
}