
SMODS.Joker{ --Peak
    key = "peak",
    config = {
        extra = {
            peak = 0.95,
            show = 5
        }
    },
    loc_txt = {
        ['name'] = 'Peak',
        ['text'] = {
            [1] = '{C:attention}Reduces Blind requirement{} after',
            [2] = 'Beating a Blind',
            [3] = '',
            [4] = '{C:inactive}Currently reduced by #2#%{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' 
            or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.peak, card.ability.extra.show}}
    end,
    
    calculate = function(self, card, context)
        if context.first_hand_drawn  then
            return {
                
                func = function()
                    if G.GAME.blind.in_blind then
                        
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "X"..tostring(card.ability.extra.peak).." Blind Size", colour = G.C.GREEN})
                        G.GAME.blind.chips = G.GAME.blind.chips * card.ability.extra.peak
                        G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                        G.HUD_blind:recalculate()
                        return true
                    end
                end
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if to_big((card.ability.extra.peak or 0)) ~= to_big(0.5) then
                return {
                    func = function()
                        card.ability.extra.peak = math.max(0, (card.ability.extra.peak) - 0.05)
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.show = (card.ability.extra.show) + 5
                            return true
                        end,
                        colour = G.C.GREEN
                    }
                }
            end
        end
    end
}