
SMODS.Joker{ --Old Man
    key = "oldman",
    config = {
        extra = {
            hands0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Old Man',
        ['text'] = {
            [1] = 'Grants {C:green}1{} extra {C:blue}hand{} during {C:attention}boss blind{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    soul_pos = {
        x = 7,
        y = 3
    },
    
    calculate = function(self, card, context)
        if context.first_hand_drawn  then
            if G.GAME.blind.boss then
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Hands", colour = G.C.GREEN})
                        
                        G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + 1
                        return true
                    end
                }
            end
        end
    end
}