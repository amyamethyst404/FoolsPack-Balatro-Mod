
SMODS.Joker{ --Selfish
    key = "selfish",
    config = {
        extra = {
            mult0 = 10
        }
    },
    loc_txt = {
        ['name'] = 'Selfish',
        ['text'] = {
            [1] = '{C:red}+10 Mult{} When any joker is {C:green}triggered {}',
            [2] = 'and this card is in the {C:attention}first {}joker slot',
            [3] = '',
            [4] = '{C:inactive}Art by @MD3vourer55726 On twitter{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.other_joker  then
            if (function()
                return G.jokers.cards[1] == card
            end)() then
                return {
                    mult = 10
                }
            end
        end
    end
}