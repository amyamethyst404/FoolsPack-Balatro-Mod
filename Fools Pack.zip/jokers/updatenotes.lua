
SMODS.Joker{ --Update Notes
    key = "updatenotes",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Update Notes',
        ['text'] = {
            [1] = '{C:dark_edition}Joker Balance Changes{}',
            [2] = 'Reworked Sodapop a bit',
            [3] = 'Added Extra Text to Rosie\'s Description for more clear info',
            [4] = 'Pineapple Joe\'s max Chips Limited from 200 -> 100',
            [5] = 'Scary Joe Price increased from $1 -> $15 and can only appear',
            [6] = 'in the shop or from Joe Dice',
            [7] = '',
            [8] = '{C:dark_edition}New Jokers/Cards{}',
            [9] = 'Added the Fools Deck!',
            [10] = 'Added the ??? Deck!',
            [11] = '',
            [12] = '{C:dark_edition}Other Stuff{}',
            [13] = 'New Menu Logo Design!',
            [14] = 'Removed Background Music as it got to repetative when playing',
            [15] = 'for a while.',
            [16] = '',
            [17] = '{C:dark_edition}Bug Fixes{}',
            [18] = '\"Hey Guys\" No longer crashes the game when the player loses.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 0,
    rarity = "fagmod_deck_exclusive",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true }
}