
SMODS.Joker{ --Dragonet
    key = "dragonet",
    config = {
        extra = {
            Ante = 1,
            currentante = 1
        }
    },
    loc_txt = {
        ['name'] = 'Dragonet',
        ['text'] = {
            [1] = 'Applies {X:red,C:white}X{} Mult equal to {C:green}half',
            [2] = 'the current ante number{} {C:inactive}(#1#) {}',
            [3] = '',
            [4] = '{C:inactive}Art by: @AKarts_14 on twitter{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Ante, card.ability.extra.currentante + ((G.GAME.round_resets.ante or 0)) * 0.5}}
    end,
    
    calculate = function(self, card, context)
        if context.ante_change  then
            return {
                func = function()
                    card.ability.extra.Ante = card.ability.extra.currentante + (G.GAME.round_resets.ante) * 0.5
                    return true
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.Ante
            }
        end
    end
}