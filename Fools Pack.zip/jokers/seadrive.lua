
SMODS.Joker{ --SeaDrive
    key = "seadrive",
    config = {
        extra = {
            blind_size0 = 0.5
        }
    },
    loc_txt = {
        ['name'] = 'SeaDrive',
        ['text'] = {
            [1] = '{C:attention}Halves Blind requirement {}on all',
            [2] = '{C:green}Non-Final Boss blinds{}',
            [3] = 'Does Not Stack With {C:purple}Peak{}',
            [4] = '',
            [5] = '{C:inactive}Art by @Lovavavavania On twitter{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.setting_blind  then
            if (not (to_big(G.GAME.blind.config.blind.key) == to_big("bl_final_acorn")) and not (to_big(G.GAME.blind.config.blind.key) == to_big("bl_final_leaf")) and not (to_big(G.GAME.blind.config.blind.key) == to_big("bl_final_vessel")) and not (to_big(G.GAME.blind.config.blind.key) == to_big("bl_final_heart")) and not (to_big(G.GAME.blind.config.blind.key) == to_big("bl_final_bell")) and not ((function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_fagmod_peak" then 
                        return true
                    end
                end
            end)())) then
                return {
                    
                    func = function()
                        if G.GAME.blind.in_blind then
                            
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "X"..tostring(0.5).." Blind Size", colour = G.C.GREEN})
                            G.GAME.blind.chips = G.GAME.blind.chips * 0.5
                            G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                            G.HUD_blind:recalculate()
                            return true
                        end
                    end
                }
            end
        end
    end
}