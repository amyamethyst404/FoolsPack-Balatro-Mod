
SMODS.Joker{ --Hey petah
    key = "heypetah",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Hey petah',
        ['text'] = {
            [1] = 'HOLY SHIT ITS {C:green}HIM{}',
            [2] = '',
            [3] = '{C:red}Hates {}{X:red,C:white}linux {} \"users\"',
            [4] = '{C:inactive}Crashes game if player is running linux{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 2,
    rarity = "fagmod_joe",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true, ["fagmod_joe_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
            if love.system.getOS() == "Linux" then
                error("EasternFarmer Was Here")
            end
        end
    end
}