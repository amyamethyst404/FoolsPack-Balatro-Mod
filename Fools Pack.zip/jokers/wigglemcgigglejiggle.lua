
SMODS.Joker{ --Wiggle McGiggleJiggle
    key = "wigglemcgigglejiggle",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Wiggle McGiggleJiggle',
        ['text'] = {
            [1] = '{C:dark_edition}When a consumable is used,',
            [2] = 'Wiggles all your Jokers{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.using_consumeable  then
            if #G.jokers.cards > 0 then
                for _, joker in ipairs(G.jokers.cards) do
                    joker:flip()
                end
            end
            return {
                message = "Flip!"
            }
        end
    end
}