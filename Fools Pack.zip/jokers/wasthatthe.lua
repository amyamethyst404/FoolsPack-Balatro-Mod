
SMODS.Joker{ --WAS THAT THE
    key = "wasthatthe",
    config = {
        extra = {
            Bites = 1
        }
    },
    loc_txt = {
        ['name'] = 'WAS THAT THE',
        ['text'] = {
            [1] = 'only works if BITE OF 87 is owned',
            [2] = '',
            [3] = 'When a Card gets {C:red}destoryed {}add {X:red,C:white}X0.1{} Mult',
            [4] = '{C:inactive}Currently: X#1# {}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true, ["fagmod_mark"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Bites}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_famod_biteof87" then 
                        return true
                    end
                end
            end)() then
                return {
                    Xmult = card.ability.extra.Bites
                }
            end
        end
        if context.remove_playing_cards  then
            return {
                func = function()
                    card.ability.extra.Bites = (card.ability.extra.Bites) + 0.1
                    return true
                end
            }
        end
    end
}