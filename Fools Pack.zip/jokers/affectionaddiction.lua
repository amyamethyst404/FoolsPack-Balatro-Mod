
SMODS.Joker{ --Affection Addiction
    key = "affectionaddiction",
    config = {
        extra = {
            emult0 = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Affection Addiction',
        ['text'] = {
            [1] = 'Every scoring card gives',
            [2] = '{X:tarot,C:white}^1.5{} {C:tarot}Mult {}if only {C:green}1{} other',
            [3] = 'joker is owned'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true, ["fagmod_Vocaloid"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if to_big(#G.jokers.cards) == to_big(2) then
                return {
                    e_mult = 1.5
                }
            end
        end
    end
}