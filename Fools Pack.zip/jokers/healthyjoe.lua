
SMODS.Joker{ --Healthy Joe
    key = "healthyjoe",
    config = {
        extra = {
            odds = 4,
            discards0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Healthy Joe',
        ['text'] = {
            [1] = '{C:green}#1# in #2# Chance{} to',
            [2] = 'not use a discard'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "fagmod_joe",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_fagmod_healthyjoe') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.pre_discard  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_b79cdb9b', 1, card.ability.extra.odds, 'j_fagmod_healthyjoe', false) then
                    SMODS.calculate_effect({
                        func = function()
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Discards", colour = G.C.GREEN})
                            
                            G.GAME.current_round.discards_left = G.GAME.current_round.discards_left + 1
                            return true
                        end}, card)
                    end
                end
            end
        end
    }