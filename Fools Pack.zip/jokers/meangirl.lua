
SMODS.Joker{ --Mean Girl
    key = "meangirl",
    config = {
        extra = {
            xmult0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Mean Girl',
        ['text'] = {
            [1] = 'When hand played {C:red}Destroy{} a {C:tarot}Tarot{}',
            [2] = 'card and give {X:red,C:white}X2{}{C:red} Mult{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    soul_pos = {
        x = 3,
        y = 3
    },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local count = 0
                for _, consumable_card in pairs(G.consumeables.cards or {}) do
                    if consumable_card.ability.set == 'Tarot' then
                        count = count + 1
                    end
                end
                return to_big(count) >= to_big(1)
            end)() then
                local target_cards = {}
                for i, consumable in ipairs(G.consumeables.cards) do
                    if consumable.ability.set == "Tarot" then
                        table.insert(target_cards, consumable)
                    end
                end
                if #target_cards > 0 then
                    local card_to_destroy = pseudorandom_element(target_cards, pseudoseed('destroy_consumable'))
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            card_to_destroy:start_dissolve()
                            return true
                        end
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed Consumable!", colour = G.C.RED})
                end
                return {
                    Xmult = 2
                }
            end
        end
        if (context.end_of_round or context.reroll_shop or context.buying_card or
            context.selling_card or context.ending_shop or context.starting_shop or 
            context.ending_booster or context.skipping_booster or context.open_booster or
            context.skip_blind or context.before or context.pre_discard or context.setting_blind or
        context.using_consumeable)   then
            if (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_fagmod_knight" then 
                        return true
                    end
                end
            end)() then
                return {
                    func = function()
                        local target_joker = nil
                        for i, joker in ipairs(G.jokers.cards) do
                            if joker.config.center.key == "j_fagmod_knight" and not joker.getting_sliced then
                                target_joker = joker
                                break
                            end
                        end
                        
                        if target_joker then
                            if target_joker.ability.eternal then
                                target_joker.ability.eternal = nil
                            end
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Weak", colour = G.C.RED})
                        end
                        return true
                    end
                }
            end
        end
    end
}