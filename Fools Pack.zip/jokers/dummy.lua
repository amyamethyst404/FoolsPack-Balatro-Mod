
SMODS.Joker{ --Dummy
    key = "dummy",
    config = {
        extra = {
            xchips0 = 2,
            chips0 = 50
        }
    },
    loc_txt = {
        ['name'] = 'Dummy',
        ['text'] = {
            [1] = 'Gives {C:blue}50 Chips{} Upon hand played',
            [2] = '',
            [3] = 'If {C:tarot}Casual{} and {C:spades}Tumor{} Jokers are owned,',
            [4] = '{X:blue,C:white}X2 Chips{}',
            [5] = '',
            [6] = '{C:inactive}Requested by Minty{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    soul_pos = {
        x = 3,
        y = 0
    },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_fagmod_casual" then 
                        return true
                    end
                end
            end)() and (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_fagmod_tumor" then 
                        return true
                    end
                end
            end)()) then
                return {
                    x_chips = 2,
                    message = "TEAM WORK!"
                }
            else
                return {
                    chips = 50
                }
            end
        end
    end
}