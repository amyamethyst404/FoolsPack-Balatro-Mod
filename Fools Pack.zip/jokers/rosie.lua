
SMODS.Joker{ --Rosie
    key = "rosie",
    config = {
        extra = {
            happy = 'Happy',
            xmult0 = 2.5,
            xchips0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Rosie',
        ['text'] = {
            [1] = 'Give {X:blue,C:white}X2{} {C:blue}Chips {}& {X:red,C:white}X2.5{} {C:red}Mult {}if joker is happy',
            [2] = 'Gets sad whenever a {C:red}discard {}is used',
            [3] = 'Gets happy after a {C:blue}hand {}is played',
            [4] = '',
            [5] = '{C:inactive}Current Mood: #1# {}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.happy}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if card.ability.extra.happy == 'Happy' then
                return {
                    Xmult = 2.5,
                    extra = {
                        x_chips = 2,
                        colour = G.C.DARK_EDITION
                    }
                }
            elseif card.ability.extra.happy == 'Sad' then
                card.ability.extra.happy = 'Happy'
            end
        end
        if context.discard  then
            card.ability.extra.happy = 'Sad'
        end
    end
}