
SMODS.Joker{ --Mark Fischbach
    key = "markfischbach",
    config = {
        extra = {
            xchips0 = 1.01,
            xmult0 = 1.01
        }
    },
    loc_txt = {
        ['name'] = 'Mark Fischbach',
        ['text'] = {
            [1] = '{X:red,C:white}X1.01{} {C:blue}Chips {}And {C:red}Mult{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true, ["fagmod_mark"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                x_chips = 1.01,
                extra = {
                    Xmult = 1.01
                }
            }
        end
    end
}