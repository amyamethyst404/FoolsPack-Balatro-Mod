
SMODS.Joker{ --ClownFish
    key = "clownfish",
    config = {
        extra = {
            xmult0 = 3
        }
    },
    loc_txt = {
        ['name'] = 'ClownFish',
        ['text'] = {
            [1] = '{X:red,C:white}X3{} Mult if there are',
            [2] = 'no {C:attention}Face cards{} are',
            [3] = 'in the deck',
            [4] = '',
            [5] = '{C:inactive}Art By: @ErizKun on twitter{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
                local count = 0
                for _, playing_card in pairs(G.playing_cards or {}) do
                    if playing_card:get_id() == 11 then
                        count = count + 1
                    end
                end
                return to_big(count) == to_big(0)
            end)() and (function()
                local count = 0
                for _, playing_card in pairs(G.playing_cards or {}) do
                    if playing_card:get_id() == 12 then
                        count = count + 1
                    end
                end
                return to_big(count) == to_big(0)
            end)() and (function()
                local count = 0
                for _, playing_card in pairs(G.playing_cards or {}) do
                    if playing_card:get_id() == 13 then
                        count = count + 1
                    end
                end
                return to_big(count) == to_big(0)
            end)()) then
                return {
                    Xmult = 3
                }
            end
        end
    end
}