
SMODS.Joker{ --The Boy
    key = "theboy",
    config = {
        extra = {
            chips0 = 25
        }
    },
    loc_txt = {
        ['name'] = 'The Boy',
        ['text'] = {
            [1] = '{C:inactive}Splat!{}',
            [2] = '',
            [3] = 'Each played card',
            [4] = 'gives {C:blue}+25 Chips{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    soul_pos = {
        x = 5,
        y = 3
    },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound("fagmod_splat")
                    
                    return true
                end,
            }))
            return {
                chips = 25
            }
        end
    end
}