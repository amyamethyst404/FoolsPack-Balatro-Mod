
SMODS.Joker{ --Silent hero
    key = "silenthero",
    config = {
        extra = {
            xmult0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Silent hero',
        ['text'] = {
            [1] = 'Does Nothing Alone',
            [2] = '',
            [3] = 'If {C:green}ToothPaste Boy{} and {C:purple}Mean Girl{}',
            [4] = 'Are owned, {C:enhanced}Balance Mult and Chips{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    soul_pos = {
        x = 1,
        y = 3
    },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_fagmod_knight" then 
                        return true
                    end
                end
            end)() then
                return {
                    Xmult = 2
                }
            elseif ((function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_fagmod_toothpasteboy" then 
                        return true
                    end
                end
            end)() and (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_fagmod_meangirl" then 
                        return true
                    end
                end
            end)()) then
                return {
                    balance = true
                }
            end
        end
    end
}