
SMODS.Joker{ --Gimmick Girl
    key = "gimmickgirl",
    config = {
        extra = {
            odds = 2
        }
    },
    loc_txt = {
        ['name'] = 'Gimmick Girl',
        ['text'] = {
            [1] = '{C:green}#1# in 2 Chance{} to create a',
            [2] = 'playing card with {C:tarot}random {}stats',
            [3] = '{C:green}#1# in 2 Chance{} to create a',
            [4] = '{C:tarot}random {}Joker when blind is',
            [5] = 'selected'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true, ["fagmod_Vocaloid"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_fagmod_gimmickgirl')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_fagmod_gimmickgirl')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2}}
    end,
    
    calculate = function(self, card, context)
        if context.first_hand_drawn  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_599cf595', 1, card.ability.extra.odds, 'j_fagmod_gimmickgirl', false) then
                    SMODS.calculate_effect({func = function()
                        local card_front = pseudorandom_element(G.P_CARDS, pseudoseed('add_card_hand'))
                        local base_card = create_playing_card({
                            front = card_front,
                            center = pseudorandom_element({G.P_CENTERS.m_gold, G.P_CENTERS.m_steel, G.P_CENTERS.m_glass, G.P_CENTERS.m_wild, G.P_CENTERS.m_mult, G.P_CENTERS.m_lucky, G.P_CENTERS.m_stone}, pseudoseed('add_card_hand_enhancement'))
                        }, G.discard, true, false, nil, true)
                        
                        base_card:set_seal(pseudorandom_element({'Gold','Red','Blue','Purple','fagmod_guided'}, pseudoseed('add_card_hand_seal')), true)
                        
                        base_card:set_edition(pseudorandom_element({'e_foil','e_holo','e_polychrome','e_negative','e_fagmod_glitched'}, pseudoseed('add_card_hand_edition')), true)
                        
                        G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                        base_card.playing_card = G.playing_card
                        table.insert(G.playing_cards, base_card)
                        
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                G.hand:emplace(base_card)
                                base_card:start_materialize()
                                SMODS.calculate_context({ playing_card_added = true, cards = { base_card } })
                                return true
                            end
                        }))
                    end}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Added Card to Hand!", colour = G.C.GREEN})
                end
                if SMODS.pseudorandom_probability(card, 'group_1_9c7d11ee', 1, card.ability.extra.odds, 'j_fagmod_gimmickgirl', false) then
                    SMODS.calculate_effect({func = function()
                        
                        local created_joker = false
                        if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                            created_joker = true
                            G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    local joker_card = SMODS.add_card({ set = 'Joker' })
                                    if joker_card then
                                        
                                        
                                    end
                                    G.GAME.joker_buffer = 0
                                    return true
                                end
                            }))
                        end
                        if created_joker then
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
                        end
                        return true
                    end}, card)
                end
            end
        end
    end
}