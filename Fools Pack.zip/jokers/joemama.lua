
SMODS.Joker{ --Joe Mama
    key = "joemama",
    config = {
        extra = {
            sixes = 4,
            seves = 4,
            _6sindeck = 0,
            _7sindeck = 0,
            xmult0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Joe Mama',
        ['text'] = {
            [1] = 'If there are an {C:attention}equal amount{} of {C:green}6 and 7\'s{}',
            [2] = 'in your deck, {X:red,C:white}X2{} {C:red}Mult{}{C:white}.... . . .{}  {C:inactive} (#1# | #2#) {}',
            [3] = '',
            [4] = '{C:green}\"XBOX LIVEEEEEEE\"{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "fagmod_joe",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers joe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
    return {vars = {card.ability.extra.sixes, card.ability.extra.seves, (function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if card.base.id == 6 then count = count + 1 end end; return count end)(), (function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if card.base.id == 7 then count = count + 1 end end; return count end)()}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
        if to_big((function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if card.base.id == 6 then count = count + 1 end end; return count end)()) == to_big((function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if card.base.id == 7 then count = count + 1 end end; return count end)()) then
            return {
                Xmult = 2
            }
        end
    end
    if (context.end_of_round or context.reroll_shop or context.buying_card or
        context.selling_card or context.ending_shop or context.starting_shop or 
        context.ending_booster or context.skipping_booster or context.open_booster or
        context.skip_blind or context.before or context.pre_discard or context.setting_blind or
    context.using_consumeable)   then
        return {
            func = function()
            card.ability.extra.sixes = (function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if card.base.id == 6 then count = count + 1 end end; return count end)()
                return true
            end,
            extra = {
                func = function()
                card.ability.extra.seves = (function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if card.base.id == 7 then count = count + 1 end end; return count end)()
                    return true
                end,
                colour = G.C.BLUE
            }
        }
    end
end
}