
SMODS.Joker{ --LOST MEDIA
    key = "lostmedia",
    config = {
        extra = {
            discards0 = 3,
            hands0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'LOST MEDIA',
        ['text'] = {
            [1] = '{C:attention}+3{} {C:red}Discards{}',
            [2] = 'Sets {C:blue}Hands{} to {C:green}1{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true, ["fagmod_Vocaloid"] = true },
    
    calculate = function(self, card, context)
        if context.first_hand_drawn  then
            return {
                
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(3).." Discards", colour = G.C.GREEN})
                    
                    G.GAME.current_round.discards_left = G.GAME.current_round.discards_left + 3
                    return true
                end,
                extra = {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Set to "..tostring(1).." Hands", colour = G.C.BLUE})
                        G.GAME.current_round.hands_left = 1
                        return true
                    end,
                    colour = G.C.GREEN
                }
            }
        end
    end
}