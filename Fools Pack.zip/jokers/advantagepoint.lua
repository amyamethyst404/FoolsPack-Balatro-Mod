
SMODS.Joker{ --Advantage Point
    key = "advantagepoint",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Advantage Point',
        ['text'] = {
            [1] = 'Randomly {C:red}Destroy {}a Joker',
            [2] = 'at the end of an ante',
            [3] = 'but give{C:attention} 2X its normal sell',
            [4] = 'value{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true, ["fagmod_Vocaloid"] = true },
    
    calculate = function(self, card, context)
        if context.ante_change  then
            return {
                func = function()
                    local destructable_jokers = {}
                    for i, joker in ipairs(G.jokers.cards) do
                        if joker ~= card and not SMODS.is_eternal(joker) and not joker.getting_sliced then
                            table.insert(destructable_jokers, joker)
                        end
                    end
                    local target_joker = #destructable_jokers > 0 and pseudorandom_element(destructable_jokers, pseudoseed('destroy_joker')) or nil
                    
                    if target_joker then
                        target_joker.getting_sliced = true
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                target_joker:explode({G.C.RED}, nil, 1.6)
                                return true
                            end
                        }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "360 NO SCOPE!", colour = G.C.RED})
                    end
                    return true
                end
            }
        end
    end
}