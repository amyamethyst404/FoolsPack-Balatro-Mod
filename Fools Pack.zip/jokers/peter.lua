
SMODS.Joker{ --Peter
    key = "peter",
    config = {
        extra = {
            dollars0 = 100,
            dollars = 0,
            repetitions = 99
        }
    },
    loc_txt = {
        ['name'] = 'Peter',
        ['text'] = {
            [1] = 'Gives {C:attention}$100{} at the start of each {C:green}Ante{}',
            [2] = 'Sets money to {C:attention}$0{} when boss blind defeated',
            [3] = 'Destory\'s all jokers when boss blind defeated',
            [4] = '',
            [5] = '{C:inactive}Family Guy Deck Exclusive{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 67,
    rarity = "fagmod_deck_exclusive",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'sou' 
            or args.source == 'rif' or args.source == 'rta' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.ante_change  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = 100
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Set to $"..tostring(100), colour = G.C.MONEY})
                    return true
                end
            }
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
            if true then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = 0
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Set to $"..tostring(0), colour = G.C.MONEY})
                        return true
                    end
                    ,
                    func = function()
                        for i = 1, 99 do
                            SMODS.calculate_effect({func = function()
                                local destructable_jokers = {}
                                for i, joker in ipairs(G.jokers.cards) do
                                    if joker ~= card and not SMODS.is_eternal(joker) and not joker.getting_sliced then
                                        table.insert(destructable_jokers, joker)
                                    end
                                end
                                local target_joker = #destructable_jokers > 0 and pseudorandom_element(destructable_jokers, pseudoseed('destroy_joker')) or nil
                                
                                if target_joker then
                                    target_joker.getting_sliced = true
                                    G.E_MANAGER:add_event(Event({
                                        func = function()
                                            target_joker:explode({G.C.RED}, nil, 1.6)
                                            return true
                                        end
                                    }))
                                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                                end
                                return true
                            end}, card)
                        end
                        return true
                    end
                }
            end
        end
    end
}