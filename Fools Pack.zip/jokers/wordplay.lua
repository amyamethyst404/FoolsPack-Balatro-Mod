
SMODS.Joker{ --Word Play
    key = "wordplay",
    config = {
        extra = {
            Mult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Word Play',
        ['text'] = {
            [1] = 'If {C:green}4 or 5{} Jokers are owned, {C:hearts}Destroy {}the',
            [2] = 'Right most joker, and add {X:red,C:white}0.25x {}{C:red} Mult{}',
            [3] = '',
            [4] = '{C:inactive}Currently #1# {}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_joker"] = true, ["fagmod_Vocaloid"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Mult}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (to_big(#G.jokers.cards) == to_big(4) or to_big(#G.jokers.cards) == to_big(5)) then
                local target_joker = nil
                for i = #G.jokers.cards, 1, -1 do
                    local joker = G.jokers.cards[i]
                    if joker ~= card and not SMODS.is_eternal(joker) and not joker.getting_sliced then
                        target_joker = joker
                        break
                    end
                end
                
                if target_joker then
                    target_joker.getting_sliced = true
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                            return true
                        end
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                end
                card.ability.extra.Mult = (card.ability.extra.Mult) + 0.25
            else
                return {
                    Xmult = card.ability.extra.Mult
                }
            end
        end
    end
}