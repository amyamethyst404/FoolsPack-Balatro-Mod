
SMODS.Joker{ --Big Boobs
    key = "bigboobs",
    config = {
        extra = {
            mod_probability0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Big Boobs',
        ['text'] = {
            [1] = 'Search him up on your',
            [2] = 'school computer',
            [3] = '{C:inactive}Halfs all probability\'s{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.mod_probability  then
            local numerator, denominator = context.numerator, context.denominator
            denominator = denominator * (2)
            return {
                numerator = numerator, 
                denominator = denominator
            }
        end
    end
}