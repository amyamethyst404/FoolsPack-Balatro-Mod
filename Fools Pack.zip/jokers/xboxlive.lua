
SMODS.Joker{ --XBOX LIVE
    key = "xboxlive",
    config = {
        extra = {
            xmult0 = 1.25
        }
    },
    loc_txt = {
        ['name'] = 'XBOX LIVE',
        ['text'] = {
            [1] = 'Each {C:uncommon}Joe{} card Owned gives {X:red,C:white}X1.25{} {C:red}Mult{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = "fagmod_joe",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.other_joker  then
            if (function()
                return context.other_joker.config.center.rarity == "fagmod_joe"
            end)() then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        play_sound("fagmod_xboxlive")
                        
                        return true
                    end,
                }))
                return {
                    Xmult = 1.25
                }
            end
        end
    end
}