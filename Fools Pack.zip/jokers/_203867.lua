
SMODS.Joker{ --20 38 67
    key = "_203867",
    config = {
        extra = {
            xmult0 = 2,
            xchips0 = 3.8,
            dollars0 = 6.7
        }
    },
    loc_txt = {
        ['name'] = '20 38 67',
        ['text'] = {
            [1] = '{X:red,C:white}X2.0 {} Mult',
            [2] = '{X:blue,C:white}X3.8{} Chips',
            [3] = '{X:money,C:white}+6.7{} Cash'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = 2,
                message = "its 20!",
                extra = {
                    x_chips = 3.8,
                    message = "its 38!",
                    colour = G.C.DARK_EDITION,
                    extra = {
                        
                        func = function()
                            
                            local current_dollars = G.GAME.dollars
                            local target_dollars = G.GAME.dollars + 6.7
                            local dollar_value = target_dollars - current_dollars
                            ease_dollars(dollar_value)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "SIXXXX SEVEEENNN", colour = G.C.MONEY})
                            return true
                        end,
                        colour = G.C.MONEY
                    }
                }
            }
        end
    end
}