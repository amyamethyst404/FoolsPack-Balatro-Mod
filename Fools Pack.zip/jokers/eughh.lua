
SMODS.Joker{ --EUGHH
    key = "eughh",
    config = {
        extra = {
            Chips = 0
        }
    },
    loc_txt = {
        ['name'] = 'EUGHH',
        ['text'] = {
            [1] = '{C:blue}+50{} Chips Each card {C:attention}sold{}',
            [2] = '{C:inactive}#1# {}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true, ["fagmod_mark"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Chips}}
    end,
    
    calculate = function(self, card, context)
        if context.selling_card  then
            return {
                func = function()
                    card.ability.extra.Chips = (card.ability.extra.Chips) + 50
                    return true
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = card.ability.extra.Chips
            }
        end
    end
}