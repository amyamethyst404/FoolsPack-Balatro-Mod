
SMODS.Joker{ --Info Card
    key = "infocard",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Info Card',
        ['text'] = {
            [1] = '{C:dark_edition}Welcome!{}',
            [2] = 'Thanks for playing my mod! I made this as a joke with a few of my',
            [3] = 'friends but it turned out to become a lot more than just a joke mod.',
            [4] = 'All the jokers here are from many of my amazing friends and i had a lot',
            [5] = 'of help with ideas. Some things may crash the game, and if they do, check',
            [6] = 'the crash screen for a message because some of them might be intentional',
            [7] = '{C:dark_edition}Regarding Card Designs{}',
            [8] = 'While i did make all the images into Cards, i did not make any of the art or',
            [9] = 'images inside the jokers themselves. I tried my best to credit those artists',
            [10] = 'and if i missed one, or you want your card removed, just let me know on discord!',
            [11] = 'For many of the vocaloid cards, The name of the card is the name of the song the',
            [12] = 'image is from! (Out of control is from affection addiction)',
            [13] = '{C:dark_edition}Other Stuff{}',
            [14] = '-  {C:red}Kitsu {}- Made basically everything here!',
            [15] = '- {C:blue}Sodapop {}-{C:diamonds} Roi dadidou{} - {C:planet}Mintyluxa {}- Helped with some joker ideas!',
            [16] = '- {C:purple}Guyman {}-{C:diamonds} Roi dadidou{} - Helped with playtesting the full mod!',
            [17] = 'This was made with {C:green}Joker Forge{} as i am to lazy to actually code this lol.',
            [18] = 'This mod might be updated more later!',
            [19] = 'Discord: @amethyst_404',
            [20] = 'Twitter: @Am3thyst4_4',
            [21] = '',
            [22] = '{C:inactive}Card image was Drawn by @Ziggler_0 On twitter!{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 0,
    rarity = "fagmod_deck_exclusive",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'rif' 
            or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end
}