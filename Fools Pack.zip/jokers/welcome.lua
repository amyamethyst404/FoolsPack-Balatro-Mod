
SMODS.Joker{ --Welcome
    key = "welcome",
    config = {
        extra = {
            Cash = 4,
            currentmoney = 4
        }
    },
    loc_txt = {
        ['name'] = 'Welcome',
        ['text'] = {
            [1] = 'Grants {X:money,C:white}5%{} of current money',
            [2] = 'When a {C:green}shop {}is entered',
            [3] = '{C:inactive}(#1#){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true, ["fagmod_mark"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Cash, card.ability.extra.currentmoney + ((G.GAME.dollars or 0)) * 0.05}}
    end,
    
    calculate = function(self, card, context)
        if context.starting_shop  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + card.ability.extra.Cash
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.Cash), colour = G.C.MONEY})
                    return true
                end
            }
        end
        if (context.end_of_round or context.reroll_shop or context.buying_card or
            context.selling_card or context.ending_shop or context.starting_shop or 
            context.ending_booster or context.skipping_booster or context.open_booster or
            context.skip_blind or context.before or context.pre_discard or context.setting_blind or
        context.using_consumeable)   then
            return {
                func = function()
                    card.ability.extra.Cash = card.ability.extra.currentmoney + (G.GAME.dollars) * 0.05
                    return true
                end
            }
        end
    end
}