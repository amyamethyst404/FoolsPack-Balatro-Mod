
SMODS.Joker{ --Copycat
    key = "copycat",
    config = {
        extra = {
            Mult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Copycat',
        ['text'] = {
            [1] = 'Add {X:red,C:white}X0.25{} Mult Each time a',
            [2] = '{C:dark_edition}Spectral {}Card is used',
            [3] = '{C:inactive}Currently: #1# {}',
            [4] = '',
            [5] = '{C:inactive}Art by @Vexliam_K on Twitter{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Mult}}
    end,
    
    calculate = function(self, card, context)
        if context.using_consumeable  then
            if context.consumeable and context.consumeable.ability.set == 'Spectral' then
                return {
                    func = function()
                        card.ability.extra.Mult = (card.ability.extra.Mult) + 0.25
                        return true
                    end
                }
            end
        end
    end
}