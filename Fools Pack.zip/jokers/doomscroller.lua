
SMODS.Joker{ --DoomScroller
    key = "doomscroller",
    config = {
        extra = {
            reroll_amount = '3'
        }
    },
    loc_txt = {
        ['name'] = 'DoomScroller',
        ['text'] = {
            [1] = 'First  {C:green}3{} Rerolls are {C:gold}Free{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true, ["fagmod_Vocaloid"] = true },
    
    calculate = function(self, card, context)
    end,
    
    add_to_deck = function(self, card, from_debuff)
        SMODS.change_free_rerolls(3)
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        SMODS.change_free_rerolls(-(3))
    end
}