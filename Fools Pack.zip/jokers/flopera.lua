
SMODS.Joker{ --Flop era
    key = "flopera",
    config = {
        extra = {
            card_draw0 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Flop era',
        ['text'] = {
            [1] = 'Draw {C:green}3{} Cards to {C:blue}hand{} before',
            [2] = 'Scoring Cards'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true, ["fagmod_Vocaloid"] = true },
    
    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
            if G.hand and #G.hand.cards > 0 then
                SMODS.draw_cards(3)
            end
            return {
                message = "+"..tostring(3).." Cards Drawn"
            }
        end
    end
}