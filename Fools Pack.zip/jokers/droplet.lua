
SMODS.Joker{ --Droplet
    key = "droplet",
    config = {
        extra = {
            Vouchersredeamed = 0,
            totalvouchersbought = 0
        }
    },
    loc_txt = {
        ['name'] = 'Droplet',
        ['text'] = {
            [1] = 'Adds {C:blue}Chips{} Equal to the {C:green}total amount',
            [2] = 'of Vouchers redeemed this profile{} {C:inactive}(#2#){}',
            [3] = '',
            [4] = '{C:inactive}Art by: @Lovavavavania on Twitter {}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Vouchersredeamed, (G.PROFILES[G.SETTINGS.profile].career_stats.c_vouchers_bought or 0)}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = card.ability.extra.Vouchersredeamed
            }
        end
        if (context.end_of_round or context.reroll_shop or context.buying_card or
            context.selling_card or context.ending_shop or context.starting_shop or 
            context.ending_booster or context.skipping_booster or context.open_booster or
            context.skip_blind or context.before or context.pre_discard or context.setting_blind or
        context.using_consumeable)   then
            return {
                func = function()
                    card.ability.extra.Vouchersredeamed = (G.PROFILES[G.SETTINGS.profile].career_stats.c_vouchers_bought or 0)
                    return true
                end
            }
        end
    end
}