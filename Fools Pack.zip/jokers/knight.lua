
SMODS.Joker{ --Knight
    key = "knight",
    config = {
        extra = {
            emult0 = 1.1
        }
    },
    loc_txt = {
        ['name'] = 'Knight',
        ['text'] = {
            [1] = 'Every Friend card held in hand gives {X:enhanced,C:white}^1.1{} {C:red}Mult{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    soul_pos = {
        x = 7,
        y = 2
    },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if SMODS.get_enhancements(context.other_card)["m_fagmod_friend"] == true then
                return {
                    e_mult = 1.1
                }
            end
        end
    end
}