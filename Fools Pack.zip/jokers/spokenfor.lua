
SMODS.Joker{ --Spoken For
    key = "spokenfor",
    config = {
        extra = {
            Idofnextjoker = 0,
            currenthandsize = 1
        }
    },
    loc_txt = {
        ['name'] = 'Spoken For',
        ['text'] = {
            [1] = 'Add {C:blue}15 Chips{} per hand size'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true, ["fagmod_Vocaloid"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Idofnextjoker, card.ability.extra.currenthandsize + (((G.hand and G.hand.config.card_limit or 0) or 0)) * 15}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = card.ability.extra.Idofnextjoker
            }
        end
        if (context.end_of_round or context.reroll_shop or context.buying_card or
            context.selling_card or context.ending_shop or context.starting_shop or 
            context.ending_booster or context.skipping_booster or context.open_booster or
            context.skip_blind or context.before or context.pre_discard or context.setting_blind or
        context.using_consumeable)   then
            return {
                func = function()
                    card.ability.extra.Idofnextjoker = card.ability.extra.currenthandsize + ((G.hand and G.hand.config.card_limit or 0)) * 15
                    return true
                end
            }
        end
    end
}