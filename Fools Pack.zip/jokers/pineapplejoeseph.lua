
SMODS.Joker{ --Pineapplejoeseph
    key = "pineapplejoeseph",
    config = {
        extra = {
            Joe = 100
        }
    },
    loc_txt = {
        ['name'] = 'Pineapplejoeseph',
        ['text'] = {
            [1] = '{C:blue}+#1# Chips{}',
            [2] = 'can add or remove 100 Chips',
            [3] = '',
            [4] = '{C:inactive}\"Hey, look at this cool pineapple i just found... isnt it so cool and epic and awsome sause, you should look at it forever, and ever, and ever... its a really awsome pineapple\"{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = "fagmod_joe",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true, ["fagmod_joe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Joe}}
    end,
    
    calculate = function(self, card, context)
        if (context.end_of_round or context.reroll_shop or context.buying_card or
            context.selling_card or context.ending_shop or context.starting_shop or 
            context.ending_booster or context.skipping_booster or context.open_booster or
            context.skip_blind or context.before or context.pre_discard or context.setting_blind or
        context.using_consumeable)   then
            return {
                func = function()
                    card.ability.extra.Joe = pseudorandom('RANGE:-100|100', -100, 100)
                    return true
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = card.ability.extra.Joe
            }
        end
    end
}