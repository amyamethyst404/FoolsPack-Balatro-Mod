
SMODS.Joker{ --Isaac
    key = "isaac",
    config = {
        extra = {
            mult0 = 1529.9
        }
    },
    loc_txt = {
        ['name'] = 'Isaac',
        ['text'] = {
            [1] = 'Gives {C:hearts}Mult {}based on how many hours {C:attention}roi{}',
            [2] = 'has in TBoI{C:inactive}',
            [3] = 'Well atleast sence i last updated the mod{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = 1529.9
            }
        end
    end
}