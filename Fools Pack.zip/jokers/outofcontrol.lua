
SMODS.Joker{ --Out of control
    key = "outofcontrol",
    config = {
        extra = {
            chips0 = 150
        }
    },
    loc_txt = {
        ['name'] = 'Out of control',
        ['text'] = {
            [1] = '{C:blue}+150 Chips{} if {C:green}5{} or more',
            [2] = 'jokers are owned'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true, ["fagmod_Vocaloid"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(#G.jokers.cards) > to_big(4) then
                return {
                    chips = 150
                }
            end
        end
    end
}