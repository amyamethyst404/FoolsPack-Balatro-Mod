
SMODS.Joker{ --scary joe
    key = "scaryjoe",
    config = {
        extra = {
            eepy = 0,
            mult0 = 10000
        }
    },
    loc_txt = {
        ['name'] = 'scary joe',
        ['text'] = {
            [1] = '\"Can you name {C:attention}this card{}{C:spades} “scary Joe”{} and he gives you like {C:hearts}10,000 Mult?{}\"',
            [2] = '{C:inactive}-Sodapop{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 15,
    rarity = "fagmod_joe",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fagmod_fagmod_jokers"] = true, ["fagmod_joe_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'buf' and args.source ~= 'jud' 
            or args.source == 'sho' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.eepy}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            card.ability.extra.eepy = 1
            return {
                mult = 10000,
                extra = {
                    message = "Im eepy",
                    colour = G.C.BLUE
                }
            }
        end
        if context.after and context.cardarea == G.jokers  then
            if to_big((card.ability.extra.eepy or 0)) == to_big(1) then
                return {
                    func = function()
                        local target_joker = card
                        
                        if target_joker then
                            if target_joker.ability.eternal then
                                target_joker.ability.eternal = nil
                            end
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Honk mememememe", colour = G.C.RED})
                        end
                        return true
                    end
                }
            end
        end
    end
}