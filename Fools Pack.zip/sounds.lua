SMODS.Sound{
    key="xboxlive",
    path="xboxlive.ogg",
    pitch=1,
    volume=0.5,
}

SMODS.Sound{
    key="splat",
    path="splat.ogg",
    pitch=1,
    volume=0.5,
}